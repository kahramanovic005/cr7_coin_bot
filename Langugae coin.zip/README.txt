CR7 Coin — 15 tilli Telegram bot (starter)

FAYLLAR
- bot.py: /start, til tanlash tugmalari, tanlangan tilni SQLite'da saqlash.
- requirements.txt: kerakli Python kutubxonasi.

KERAKLI SOZLAMALAR (serverdagi Environment Variables)
- BOT_TOKEN: BotFather bergan token. Uni hech kimga yubormang.
- WEB_APP_URL: Netlify saytingizning HTTPS manzili, masalan:
  https://iridescent-frangipane-dc2ba5.netlify.app

ISHLATISH
1. ZIP'ni kompyuterda oching.
2. Python 3.10+ muhitida:
   pip install -r requirements.txt
3. BOT_TOKEN va WEB_APP_URL environment variables sifatida kiriting.
4. Botni doimiy ishlaydigan Python Worker/serverga joylang.
5. Start command: python bot.py

MUHIM
- Bu bot kodi. BotFather ichiga kod qo'yilmaydi.
- Tokenni chatga, skrinshotga yoki ommaviy repozitoriyga joylamang.
- Netlify statik saytni joylaydi; bot kodi esa alohida doimiy ishlaydigan server/worker talab qiladi.
- Kod tanlangan tilni botda saqlaydi va o'yinni ochish tugmasiga ?lang=xx qo'shadi.
- Mini App HTML/JavaScript kodi shu lang parametrini o'qib, o'z matnlarini tarjima qilishi kerak.
- Hozirgi HTML'da til tarjimalari avtomatik qo'shilmagan; bu bot tomoni uchun boshlang'ich paket.
- SQLite fayli doimiy diskda saqlanishi kerak, aks holda server qayta ishga tushganda tanlovlar yo'qolishi mumkin.
